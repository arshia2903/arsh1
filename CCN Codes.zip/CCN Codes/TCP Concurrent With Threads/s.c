
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <pthread.h>

#define size 1024
#define port 8080

struct data
{
    struct sockaddr_in caddr;
    int sockfd;
    int newfd;
};

void *client(void *ptr)
{
    struct data *d1 = (struct data *)ptr;
    char arr[size];
    if (listen(d1->sockfd, 8) != 0)
    {
        perror("Listning Failed..\n");
        exit(-1);
    }
    printf("Server is Running..\n");

    int len = sizeof(d1->caddr);
    d1->newfd = accept(d1->sockfd, (struct sockaddr *)&d1->caddr, &len);
    if (d1->newfd < 0)
    {
        perror("Acception Failed..\n");
        exit(0);
    }
    while (1)
    {
        bzero(arr, size);

        read(d1->newfd, arr, size);
        if (strncmp("exit", arr, 4) == 0)
        {
            printf("Server Dissconnected..\n");
            break;
        }
        printf("Message from Client: %s", arr);
        bzero(arr, size);
        printf("Enter Message for Client: ");
        int i = 0;
        while ((arr[i++] = getchar()) != '\n')
        {
        }
        write(d1->newfd, arr, size);
        if (strncmp("exit", arr, 4) == 0)
        {
            printf("Server Dissconnected..\n");
            break;
        }
    }
}

int main()
{

    struct sockaddr_in saddr;
    pthread_t pid;
    struct data d;

    if ((d.sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("Socket Creation Failed..\n");
        exit(-1);
    }

    memset(&saddr, 0, sizeof(saddr));
    memset(&d.caddr, 0, sizeof(d.caddr));

    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(port);

    if (bind(d.sockfd, (const struct sockaddr *)&saddr, sizeof(saddr)) == -1)
    {
        perror("Binding Failed..\n");
        exit(-1);
    }
    while (1)
    {
        if (pthread_create(&pid, NULL, client, (void *)&d.caddr) != 0)
        {
            perror("Creation Failed..\n");
            exit(-1);
        }
        if (pthread_join(pid, NULL) != 0)
        {
            perror("Bad Join...\n");
            exit(-1);
        }
    }

    close(d.sockfd);
    pthread_cancel(pid);
    return 0;
}