#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>

#define size 1024
#define port 8080

int main()
{
    int sockfd;
    char arr[size];
    struct sockaddr_in saddr, caddr;

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("Socket Creation Failed..\n");
        exit(-1);
    }

    memset(&saddr, 0, sizeof(saddr));

    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(port);

    if (connect(sockfd, (const struct sockaddr *)&saddr, sizeof(saddr)) == -1)
    {
        perror("Connection Failed..\n");
        exit(-1);
    }

    while (1)
    {
        bzero(arr, size);

        printf("Enter Message for Client: ");
        int i = 0;
        while ((arr[i++] = getchar()) != '\n')
        {
        }

        write(sockfd, arr, size);
        if (strncmp("exit", arr, 4) == 0)
        {
            printf("Server Dissconnected..\n");
            break;
        }

        bzero(arr, size);
        read(sockfd, arr, size);
        if (strncmp("exit", arr, 4) == 0)
        {
            printf("Server Dissconnected..\n");
            break;
        }
        printf("Message from Client: %s", arr);
    }
    close(sockfd);
    return 0;
}