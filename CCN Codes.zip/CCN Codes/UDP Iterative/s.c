#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>

#define port 8080
#define size 1024

int main(int argc, char **argv)
{

    int sockfd;
    char arr[size];
    char *message = "halao bitch connection established..\n";
    struct sockaddr_in saddr, caddr;

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("Socket Creation Failed..\n");
        exit(-1);
    }

    memset(&saddr, 0, sizeof(saddr));
    memset(&caddr, 0, sizeof(caddr));

    saddr.sin_family = AF_INET; // ipv4
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(port);

    if (bind(sockfd, (const struct sockaddr *)&saddr, sizeof(saddr)) < 0)
    {
        perror("Socket Bind Failed../n");
        exit(-1);
    }

    printf("Server is Running...\n");
    int rec = 0;

    int len;
    len = sizeof(caddr);

    rec = recvfrom(sockfd, (char *)arr, size, MSG_WAITALL, (struct sockaddr *)&caddr, &len);
    arr[rec] = '\0';

    printf("Message from Client: %s", arr);

    sendto(sockfd, (const char *)message, strlen(message), MSG_CONFIRM, (const struct sockaddr *)&caddr, len);

    printf("Message is Sent to Client...\n");

    close(sockfd);
    return 0;
}