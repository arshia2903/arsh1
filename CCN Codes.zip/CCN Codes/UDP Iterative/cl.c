#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>

#define port 8080
#define size 1024

int main(int argc, char **argv)
{
    int sockfd;
    char arr[size];
    char *message = "Hello Server whats up..\n";

    struct sockaddr_in saddr;

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        perror("Socket Creation Failed..\n");
        exit(-1);
    }

    memset(&saddr, 0, sizeof(saddr));

    saddr.sin_family = AF_INET;
    saddr.sin_addr.s_addr = INADDR_ANY;
    saddr.sin_port = htons(port);

    int rec = 0;
    int len;
    len = sizeof(saddr);

    sendto(sockfd, (const char *)message, strlen(message), MSG_CONFIRM, (const struct sockaddr *)&saddr, len);

    rec = recvfrom(sockfd, (char *)arr, size, MSG_WAITALL, (struct sockaddr *)&saddr, &len);
    arr[rec] = '\0';
    printf("Message from Server: %s", arr);

    close(sockfd);
    return 0;
}
